package me.akaishi.anarchy.kit.commands;

import lombok.AllArgsConstructor;
import me.akaishi.anarchy.kit.Kit;
import me.akaishi.anarchy.kit.KitManager;
import me.akaishi.anarchy.util.Utils;
import net.minecraft.server.v1_12_R1.NBTTagList;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.craftbukkit.v1_12_R1.inventory.CraftInventoryPlayer;
import org.bukkit.entity.Player;

/**
 * @author akaishi
 * @since 18/07/22/ 5:19 PM
 * Este archivo fue creado para crystalpvp
 */
@AllArgsConstructor
public class CreateGKitCommand implements CommandExecutor {
    private final KitManager manager;

    @Override
    public boolean onCommand(CommandSender sender, Command command, String s, String[] args) {
        if (sender instanceof Player) {
            Player player = (Player) sender;
            if (player.hasPermission("anarchy.creategkit")) {
                if (args.length >= 1) {
                    if (!(manager.getGlobalKits().size() >= 36)) {
                        String name = args[0];
                        if (!manager.isKitRegistered(name, null)) {
                            Kit kit = new Kit(null, name);
                            NBTTagList items = new NBTTagList();
                            ((CraftInventoryPlayer) player.getInventory()).getInventory().a(items);
                            kit.setKitItems(items, true);
                            manager.registerKit(kit);
                            Utils.sendMessage(player, "&aKit con nombre creado con exito&r&a " + kit.getName());
                        } else Utils.sendMessage(player, "&cYa existe un kit con ese nombre");
                    } else Utils.sendMessage(player, "&5Se ha creado la cantidad máxima de kits globales &4(36) ");
                } else Utils.sendMessage(sender, "&5/creategkit <name>");
            } else Utils.sendMessage(sender, "&5No tienes permiso para ejecutar este comando");
        } else Utils.sendMessage(sender, "&5Debes ser un jugador para ejecutar este comando");
        return true;
    }
}
