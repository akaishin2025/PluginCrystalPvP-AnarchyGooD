package me.akaishi.anarchy.kit;

import lombok.Getter;
import me.akaishi.anarchy.event.PlayerEquipKitEvent;
import me.akaishi.anarchy.kit.util.KitIO;
import me.akaishi.anarchy.util.Utils;
import net.minecraft.server.v1_12_R1.EntityPlayer;
import net.minecraft.server.v1_12_R1.NBTTagCompound;
import net.minecraft.server.v1_12_R1.NBTTagList;
import org.bukkit.Bukkit;
import org.bukkit.craftbukkit.v1_12_R1.entity.CraftPlayer;
import org.bukkit.entity.Player;

import javax.annotation.Nullable;
import java.util.UUID;

/**
 * @author akaishi
 * @since 18/07/22/ 5:19 PM
 * Este archivo fue creado para crystalpvp
 */
@Getter
//TODO make this not chinese
public class Kit {
    private final Player owner;
    private final String name;
    private NBTTagList kitItems;

    public Kit(@Nullable Player owner, String name) {
        this.owner = owner;
        this.name = name;
        load((owner == null) ? null : owner.getUniqueId());
    }

    public void setKitItems(NBTTagList kitItems, boolean save) {
        this.kitItems = kitItems;
        if (save) {
            try {
                KitIO.saveKitData(this);
            } catch (Throwable t) {
                Utils.log("&4¡No se pudo guardar el kit en el disco! Consulte el seguimiento de pila a continuación para obtener más información.");
                t.printStackTrace();
            }
        }
    }

    public boolean delete() throws Throwable {
        return KitIO.deleteKit(this);
    }

    //Set the owners inventory to the kit's contents
    public void setOwnerLoadOut() {
        if (owner == null || !owner.isOnline()) return;
        setLoadOut(owner);
    }

    public boolean setLoadOut(Player player) {
        if (player == null || !player.isOnline()) return false;
        PlayerEquipKitEvent event = new PlayerEquipKitEvent(player, this);
        Bukkit.getPluginManager().callEvent(event);
        if (event.isCancelled()) return false;
        EntityPlayer nmsPlayer = ((CraftPlayer) player).getHandle();
        nmsPlayer.inventory.b(getKitItems());
        return true;
    }

    public void load(UUID id) {
        try {
            NBTTagCompound kitData = KitIO.loadKitData(id, getName());
            if (kitData == null) {
                kitItems = null;
                return;
            }
            kitItems = kitData.getList("InvContents", 10);
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    public boolean isGlobalKit() {
        return owner == null;
    }
}
