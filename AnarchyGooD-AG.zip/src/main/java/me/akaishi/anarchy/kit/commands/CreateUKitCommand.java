package me.akaishi.anarchy.kit.commands;

import lombok.AllArgsConstructor;
import me.akaishi.anarchy.kit.Kit;
import me.akaishi.anarchy.kit.KitManager;
import me.akaishi.anarchy.util.ItemUtil;
import me.akaishi.anarchy.util.Utils;
import net.minecraft.server.v1_12_R1.NBTTagList;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.craftbukkit.v1_12_R1.inventory.CraftInventoryPlayer;
import org.bukkit.entity.Player;

/**
 * @author akaishi
 * @since 18/07/22/ 5:19 PM
 * Este archivo fue creado para crystalpvp
 */
@AllArgsConstructor
public class CreateUKitCommand implements CommandExecutor {
    private final KitManager manager;

    @Override
    public boolean onCommand(CommandSender sender, Command command, String s, String[] args) {
        if (sender instanceof Player) {
            Player player = (Player) sender;
            if (player.hasPermission("anarchy.createukit")) {
                if (args.length >= 1) {
                    boolean tooManyKits = manager.getKits(player) != null && manager.getKits(player).size() >= 35;
                    if (!tooManyKits) {
                        String name = args[0];
                        if (!manager.isKitRegistered(name, player.getUniqueId())) {
                            Kit kit = new Kit(player, name);
                            NBTTagList items = new NBTTagList();
                            ((CraftInventoryPlayer) player.getInventory()).getInventory().a(items);
                            if (ItemUtil.containsIllegals(items)) {
                                Utils.sendMessage(player, "&4¡No puede crear un kit de usuario que contenga cosas ilegales!");
                                return true;
                            }
                            kit.setKitItems(items, true);
                            manager.registerKit(kit);
                            Utils.sendMessage(player, "&aKit con nombre creado con exito&r&a " + kit.getName());
                        } else Utils.sendMessage(player, "&5Ya existe un kit con ese nombre");
                    } else Utils.sendMessage(player, "&5&cSe ha creado la cantidad máxima de kits usuario &4(35) ");
                } else Utils.sendMessage(sender, "&5/createukit <name>");
            } else Utils.sendMessage(sender, "&5No tienes permiso para ejecutar este comando");
        } else Utils.sendMessage(sender, "&5Debes ser un jugador para ejecutar este comando");
        return true;
    }
}
