package me.akaishi.anarchy.kit.commands;

import lombok.AllArgsConstructor;
import me.akaishi.anarchy.kit.Kit;
import me.akaishi.anarchy.kit.KitManager;
import me.akaishi.anarchy.util.Utils;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

@AllArgsConstructor
public class RemoveUKitCommand implements CommandExecutor {

    private final KitManager manager;

    @Override
    public boolean onCommand(CommandSender sender, Command command, String s, String[] args) {
        if (sender instanceof Player) {
            Player player = (Player) sender;
            if (player.hasPermission("8b8tpvp.removeukit")) {
                if (args.length >= 1) {
                    String name = args[0];
                    Kit kit = manager.getKits(player).stream().filter(k -> k.getName().equalsIgnoreCase(name)).findAny().orElse(null);
                    if (kit == null) {
                        Utils.sendMessage(player, "&4No hay kit con el nombre &a" + name + "&c existente");
                        return true;
                    }
                    manager.removeKit(player, kit);
                } else Utils.sendMessage(sender, "&c/removeukit <name>");
            } else Utils.sendMessage(sender, "&5No tienes permiso para ejecutar este comando");
        } else Utils.sendMessage(sender, "&5Debes ser un jugador para ejecutar este comando");
        return true;
    }
}
