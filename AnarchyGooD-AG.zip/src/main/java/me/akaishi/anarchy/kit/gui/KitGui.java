package me.akaishi.anarchy.kit.gui;

import org.bukkit.inventory.InventoryView;

public abstract class KitGui extends InventoryView {

    public abstract void onSlotClick(int slot);
}
