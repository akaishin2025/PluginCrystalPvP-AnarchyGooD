package me.akaishi.anarchy.kit.commands;

import lombok.AllArgsConstructor;
import me.akaishi.anarchy.kit.Kit;
import me.akaishi.anarchy.kit.KitManager;
import me.akaishi.anarchy.kit.gui.selectors.KitGuiTypeSelector;
import me.akaishi.anarchy.util.Utils;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/**
 * @author akaishi
 * @since 18/07/22/ 5:19 PM
 * Este archivo fue creado para crystalpvp
 */
@AllArgsConstructor
public class KitCommand implements CommandExecutor {
    private final KitManager manager;

    @Override
    public boolean onCommand(CommandSender sender, Command command, String s, String[] args) {
        if (sender instanceof Player) {
            Player player = ((Player) sender);
            if (args.length == 1) {
                String name = args[0];
                Kit kit;
                kit = manager.getGlobalKits().stream().filter(k -> k.getName().equalsIgnoreCase(name)).findAny().orElse(null);
                if (kit == null)
                    kit = manager.getKits(player).stream().filter(k -> k.getName().equalsIgnoreCase(name)).findAny().orElse(null);
                if (kit == null) {
                    Utils.sendMessage(player, "&4No hay kit con el nombre&r&a " + name + "&r&c existente");
                    return true;
                }
                boolean equipped = kit.setLoadOut(player);
                if (equipped) Utils.sendMessage(player, "&aEquipo equipado &r&a" + kit.getName());
            } else {
                KitGuiTypeSelector guiTypeSelector = new KitGuiTypeSelector(player);
                guiTypeSelector.open();
            }
        } else Utils.sendMessage(sender, "&5Debes ser jugador para usar este comando");
        return true;
    }
}
