package me.akaishi.anarchy.command.commands;

import me.akaishi.anarchy.PVPServer;
import me.akaishi.anarchy.util.Utils;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class NetherK implements CommandExecutor {
    @Override
    public boolean onCommand(CommandSender sender, Command command, String s, String[] args) {
        if (sender instanceof Player) {
            Player player = (Player) sender;
            Utils.sendMessage(player, "&aTeletransportado a Nether 32Kpvp");
            player.teleport(PVPServer.getInstance().getNether());
        }
        return true;
    }
}
