package me.akaishi.anarchy.command;

import me.akaishi.anarchy.Manager;
import me.akaishi.anarchy.PVPServer;
import me.akaishi.anarchy.ReloadConfig;
import me.akaishi.anarchy.command.commands.*;
import me.akaishi.anarchy.command.commands.admin.RotateFrames;
import org.bukkit.configuration.ConfigurationSection;

public class GeneralCommandManager extends Manager {

    public GeneralCommandManager() {
        super("commands");
    }

    @Override // commands that are not admin commands get registered here
    public void init(PVPServer plugin) {
        plugin.getCommand("kill").setExecutor(new Kill());
        plugin.getCommand("kitcreator").setExecutor(new KitCreator());
        plugin.getCommand("spawn").setExecutor(new Hub());
        plugin.getCommand("rotateframe").setExecutor(new RotateFrames());
        plugin.getCommand("help").setExecutor(new Help());
        plugin.getCommand("clearinventory").setExecutor(new ClearInventory());
        plugin.getCommand("basura").setExecutor(new GarbageBin());
        plugin.getCommand("discord").setExecutor(new Discord());
        plugin.getCommand("netherk").setExecutor(new NetherK());
        plugin.getCommand("ping").setExecutor(new PingCommand());
        plugin.getCommand("reloadconfig").setExecutor(new ReloadConfig());
        plugin.getCommand("stats").setExecutor(new StatsCommand());

    }

    @Override
    public void destruct(PVPServer plugin) {
    }

    @Override
    public void reloadConfig(ConfigurationSection config) {

    }
}
