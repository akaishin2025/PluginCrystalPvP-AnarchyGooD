package me.akaishi.anarchy.command.commands;

import me.akaishi.anarchy.PVPServer;
import me.akaishi.anarchy.util.Utils;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class KitCreator implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command command, String name, String[] args) {
        if (sender instanceof Player) {
            Player player = (Player) sender;
            player.teleport(PVPServer.getInstance().getKitCreator());
            Utils.sendMessage(player, "&aTeletransportando a KitCreator crea tus //kits//");
        }
        return true;
    }
}
