package me.akaishi.anarchy.command.commands;

public class RenameShulker {
}
