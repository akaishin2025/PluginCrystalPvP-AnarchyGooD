package me.akaishi.anarchy.command.commands;

/*    */ import me.akaishi.anarchy.util.Utils;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class PingCommand
/*    */   implements CommandExecutor {
/*    */   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
/* 13 */     Player p = (Player)sender;
/* 14 */     if (args.length == 0) {
/* 15 */       int ping = Utils.getPing(p);
/* 16 */       Utils.sendMessage(p, Utils.getConfig().getString("ping.ping-msg").replaceAll("<ping>", ping + ""));
/*    */     }
/* 18 */     else if (Bukkit.getPlayer(args[0]) == null) {
/* 19 */       Utils.sendMessage(p, Utils.getConfig().getString("ping.ping-notonline"));
/*    */     } else {
/* 21 */       Player p2 = Bukkit.getPlayer(args[0]);
/* 22 */       int ping2 = Utils.getPing(p2);
/* 23 */       Utils.sendMessage(p, Utils.getConfig().getString("ping.ping-other").replaceAll("<ping>", ping2 + "").replaceAll("<p>", p2.getName()));
/*    */     } 
/*    */     
/* 26 */     return true;
/*    */   }
/*    */ }