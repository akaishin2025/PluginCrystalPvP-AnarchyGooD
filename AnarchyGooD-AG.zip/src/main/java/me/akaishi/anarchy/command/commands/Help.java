package me.akaishi.anarchy.command.commands;

import me.akaishi.anarchy.PVPServer;
import me.akaishi.anarchy.util.Utils;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.List;

public class Help implements CommandExecutor {

    private final List<String> helpList;

    public Help() {
        this.helpList = PVPServer.getInstance().getConfig().getStringList("HelpList");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String s, String[] args) {
        if (sender instanceof Player) {
            Player player = (Player) sender;
            Utils.sendMessage(player, "&aMostrando comandos utiles del servidor.");
            String message = ChatColor.translateAlternateColorCodes('&', String.join("\n", helpList));
            player.sendMessage(message);
        }
        return true;
    }
}
