package me.akaishi.anarchy.command.commands;

import me.akaishi.anarchy.PVPServer;
import me.akaishi.anarchy.util.Utils;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class Hub implements CommandExecutor {
    @Override
    public boolean onCommand(CommandSender sender, Command command, String s, String[] args) {
        if (sender instanceof Player) {
            Player player = (Player) sender;
            Utils.sendMessage(player, "&aTeletransportando a (Spawn/hub/lobby)");
            player.teleport(PVPServer.getInstance().getSpawn());
        }
        return true;
    }
}
