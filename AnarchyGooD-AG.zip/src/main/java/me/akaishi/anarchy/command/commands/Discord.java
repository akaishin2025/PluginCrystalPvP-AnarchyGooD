package me.akaishi.anarchy.command.commands;

import me.akaishi.anarchy.PVPServer;
import me.akaishi.anarchy.util.Utils;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.List;

public class Discord implements CommandExecutor {

    private final List<String> discordList;

    public Discord() {
        this.discordList = PVPServer.getInstance().getConfig().getStringList("DiscordList");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String s, String[] args) {
        if (sender instanceof Player) {
            Player player = (Player) sender;
            Utils.sendMessage(player, "&aMostrando el discord de nuestro servidor.");
            String message = ChatColor.translateAlternateColorCodes('&', String.join("\n", discordList));
            player.sendMessage(message);
        }
        return true;
    }
}
