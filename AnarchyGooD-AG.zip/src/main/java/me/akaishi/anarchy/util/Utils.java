package me.akaishi.anarchy.util;

import me.akaishi.anarchy.Manager;
import me.akaishi.anarchy.PVPServer;
import me.txmc.protocolapi.PacketEvent;
import net.minecraft.server.v1_12_R1.*;
import org.bukkit.Chunk;
import org.bukkit.World;
import org.bukkit.*;
import org.bukkit.craftbukkit.v1_12_R1.entity.CraftPlayer;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.configuration.file.FileConfiguration;
import me.clip.placeholderapi.PlaceholderAPI;

import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.ComponentBuilder;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.TextComponent;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;



import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.DecimalFormat;
import java.util.Arrays;

public class Utils {
    public static final String PREFIX = Utils.getConfig().getString("prefix.set-prefix"); //"&b[&1&lAnarchy&4&lGooD&b]&a";
    private static final DecimalFormat format = new DecimalFormat("#.##");
    private static final List<EntityType> invalidEntityTypes = Arrays.asList(EntityType.PLAYER, EntityType.ITEM_FRAME, EntityType.ARMOR_STAND);

    public static String translateChars(String input) {
        return ChatColor.translateAlternateColorCodes('&', input);
    }

    /**
     * Runs a task on bukkit's main thread
     *
     * @param runnable The task to be run
     */
    public static void run(Runnable runnable) {
        Bukkit.getScheduler().runTask(PVPServer.getInstance(), runnable);
    }

    /**
     * Will attempt to invoke a method called sendMessage(String.class) on the object given
     *
     * @param obj     The recipient
     * @param message The message to be sent
     */
    public static void sendMessage(Object obj, String message) {
        message = String.format("%s &a➠&5 %s", PREFIX, message);
        message = translateChars(message);
        try {
            Method method = obj.getClass().getMethod("sendMessage", String.class);
            method.setAccessible(true);
            method.invoke(obj, message);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void kick(Player player, String message) {
        message = String.format("%s &5->&5 %s", PREFIX, message);
        message = translateChars(message);
        String finalMessage = message;
        run(() -> player.kickPlayer(finalMessage));
    }

    public static void log(String message) {
        message = translateChars(message);
        PVPServer.getInstance().getLogger().log(Level.INFO, String.format("%s%c", message, Character.MIN_VALUE));
    }

    public static void log(String message, Manager manager) {
        message = translateChars(message);
        message = String.format("[&3%s&r] %s", manager.getName(), message);
        PVPServer.getInstance().getLogger().log(Level.INFO, message);
    }

    public static String formatLocation(Location location) {
        double x = location.getX();
        double y = location.getY();
        double z = location.getZ();
        World world = location.getWorld();
        return "&3world&r&a " + world.getName() + " &r&3X:&r&a " + format.format(x) + " &r&3Y:&r&a " + format.format(y) + " &r&3Z:&r&a " + format.format(z);
    }

    public static ItemStack shallowReadItemStack(PacketDataSerializer buf) {
        short itemID = buf.readShort();
        if (itemID < 0) return net.minecraft.server.v1_12_R1.ItemStack.a;
        byte count = buf.readByte();
        short damage = buf.readShort();
        return new net.minecraft.server.v1_12_R1.ItemStack(Item.getById(itemID), count, damage);
    }

    public static void clearCurrentContainer(EntityPlayer player) {
        if (!(player.activeContainer instanceof ContainerChest)) return;
        IInventory inventory = ((ContainerChest) player.activeContainer).e();
        for (int i = 0; i < inventory.getSize(); i++) inventory.setItem(i, ItemStack.a);
        inventory.update();
        log(String.format("&aInventario borrado&r&3 %s&r&a con ID de ventana&r&3 %d&r&a porque tenía demasiados datos NBT", inventory.getClass().getSimpleName(), player.activeContainer.windowId));
    }

    public static boolean isIllegallyEnchanted(org.bukkit.inventory.ItemStack itemStack) {
        return itemStack.getEnchantments().entrySet().stream().anyMatch(e -> e.getValue() > e.getKey().getMaxLevel());
    }

    public static void removeEntities() {
        for (World world : Bukkit.getServer().getWorlds()) {
            for (Chunk chunk : world.getLoadedChunks()) {
                for (org.bukkit.entity.Entity entity : chunk.getEntities()) {
                    if (invalidEntityTypes.contains(entity.getType())) return;
                    entity.remove();
                }
            }
        }
    }

    // fix npe issue with Bukkit.getWorld();
    public static World getWorld(String worldName) {
        for (World world : Bukkit.getWorlds()) {
            String name = world.getName();
            if (name.equalsIgnoreCase(worldName)) {
                return world;
            }
        }
        return null;
    }

    public static void cancelAndLagback(PacketEvent.Incoming event) {
        event.setCancelled(true);
        Player player = event.getPlayer();
        EntityPlayer ep = ((CraftPlayer) player).getHandle();
        run(() -> ep.playerConnection.teleport(player.getLocation()));
    }

    public static boolean usingPAPI = false;
    public void onEnable() {
        //PlaceholderAPI
        if(Bukkit.getPluginManager().isPluginEnabled("PlaceholderAPI")){
            usingPAPI = true;
        }
    }

    public static FileConfiguration getConfig() {
        return PVPServer.getPlugin().getConfig();
    }

    
    public static void sendRawMessage(Player p, String message) {
        if (PVPServer.usingPAPI) {
        String messagewoutpapi = ChatColor.translateAlternateColorCodes('&', message);
        String finalmessage = PlaceholderAPI.setPlaceholders(p, messagewoutpapi);
        p.sendMessage(finalmessage);
    } else {
        p.sendMessage(ChatColor.translateAlternateColorCodes('&', message));
    } 
    }



    public static int getPing(Player p) {
        try {
          String a = Bukkit.getServer().getClass().getPackage().getName().substring(23);
          Class<?> b = Class.forName("org.bukkit.craftbukkit." + a + ".entity.CraftPlayer");
          Object c = b.getMethod("getHandle", new Class[0]).invoke(p, new Object[0]);
          int ping = ((Integer)c.getClass().getDeclaredField("ping").get(c)).intValue();
          return ping;
        } catch (ClassNotFoundException|NoSuchMethodException e) {
          return -1;
        } catch (IllegalAccessException e) {
          e.printStackTrace();
        } catch (InvocationTargetException e) {
          e.printStackTrace();
        } catch (NoSuchFieldException e) {
          e.printStackTrace();
        } 
        return -2;
    }

    public static String getPrefix() {
        return "&b[&1&lAnarchy&4&lGooD&b]&5";
    }

	public static void println(String message) {
		System.out.println(ChatColor.translateAlternateColorCodes('&', message));

	}

	public static void secondPass(HashMap<Player, Integer> hashMap) {
		for (Map.Entry<Player, Integer> violationEntry : hashMap.entrySet()) {
			if (violationEntry.getValue() > 0)
				violationEntry.setValue(violationEntry.getValue() - 1);
		}
	}

	public static void kickPlayer(Player player, String string) {
		player.kickPlayer(ChatColor.translateAlternateColorCodes('&', string));
	}

	public static void crashPlayer(Player player) {
		for (int i = 0; i < 100; i++) {
			player.spawnParticle(Particle.EXPLOSION_HUGE, player.getLocation(), Integer.MAX_VALUE, 1, 1, 1);
		}
	}

	public static double getTps() {
        return (Math.round(Bukkit.getServer().getTPS()[0]));
    }

	public static void sendOpMessage(String message) {
		for (Player online : Bukkit.getOnlinePlayers()) {
			if (online.isOp()) {
				online.sendMessage(ChatColor.translateAlternateColorCodes('&', message));

			}
		}
	}

	public static Player getNearbyPlayer(int i, Location loc) {
		Player plrs = null;
		for (Player nearby : loc.getNearbyPlayers(i)) {
			plrs = nearby;

		}
		return plrs;

	}

	public static void sendClickableMessage(Player player, String message, String hoverText, String cmd, ClickEvent.Action action) {
		TextComponent msg = new TextComponent(net.md_5.bungee.api.ChatColor.translateAlternateColorCodes('&', message));
		msg.setClickEvent(new ClickEvent(action, cmd));
		msg.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT,
				new ComponentBuilder(net.md_5.bungee.api.ChatColor.translateAlternateColorCodes('&', hoverText))
						.create()));
		player.spigot().sendMessage(msg);
	}
}
