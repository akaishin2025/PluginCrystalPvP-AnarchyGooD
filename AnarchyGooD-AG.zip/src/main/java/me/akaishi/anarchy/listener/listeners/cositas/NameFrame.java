package me.akaishi.anarchy.listener.listeners.cositas;

import me.akaishi.anarchy.PVPServer;
import me.akaishi.anarchy.util.Utils;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Rotation;
import org.bukkit.entity.ItemFrame;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractAtEntityEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public class NameFrame implements Listener {
    PVPServer plugin;

    public NameFrame() {
        this.plugin = plugin;
    }
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onClick(PlayerInteractAtEntityEvent event) {
        if (event.getRightClicked() instanceof ItemFrame) {
            ItemFrame frame = (ItemFrame)event.getRightClicked();
            frame.setRotation(Rotation.NONE);
            setupGui(event.getPlayer(), frame);
            event.setCancelled(true);
        }
    }

    private void setupGui(Player player, ItemFrame frame) {
        ItemStack item = frame.getItem();
        item.setAmount(item.getMaxStackSize());
        Inventory inventory = Bukkit.createInventory(null, 9, ChatColor.translateAlternateColorCodes('&', Utils.getConfig().getString("FrameFormat")));
        for (int i = 0; i < inventory.getSize(); i++)
            inventory.setItem(i, item);
        frame.setRotation(Rotation.NONE);
        player.openInventory(inventory);
        if (!frame.isInvulnerable())
            frame.setInvulnerable(true);
    }
}
