package me.akaishi.anarchy.listener;

import me.akaishi.anarchy.Manager;
import me.akaishi.anarchy.PVPServer;
import me.akaishi.anarchy.command.CommandWhitelist;
import me.akaishi.anarchy.event.eventposters.*;
import me.akaishi.anarchy.listener.listeners.PvPListeners;
import me.akaishi.anarchy.listener.listeners.cositas.BlockRedstone;
import me.akaishi.anarchy.listener.listeners.cositas.NameFrame;
import me.akaishi.anarchy.listener.listeners.exploits.IllegalKits;
import me.akaishi.anarchy.listener.listeners.frames.FrameListener;
import net.minecraft.server.v1_12_R1.*;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;

public class GeneralListenerManager extends Manager {
    public GeneralListenerManager() {
        super("general");
    }

    @Override // listeners and packet listeners that aren't specific to a feature get registered here
    public void init(PVPServer plugin) {
        Bukkit.getPluginManager().registerEvents(new PvPListeners(), plugin);
        Bukkit.getPluginManager().registerEvents(new FrameListener(), plugin);
        Bukkit.getPluginManager().registerEvents(new IllegalKits(), plugin);
        Bukkit.getPluginManager().registerEvents(new CommandWhitelist(), plugin);
        Bukkit.getPluginManager().registerEvents(new BlockRedstone(), plugin);
        Bukkit.getPluginManager().registerEvents(new NameFrame(), plugin);
        plugin.getDispatcher().register(new ListenerArmSwing(), PacketPlayInArmAnimation.class);
        plugin.getDispatcher().register(new ListenerItemFrameUse(), PacketPlayInUseEntity.class);
    }

    @Override
    public void destruct(PVPServer plugin) {

    }

    @Override
    public void reloadConfig(ConfigurationSection config) {

    }
}
