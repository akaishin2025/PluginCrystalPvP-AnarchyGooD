package me.akaishi.anarchy.listener.listeners.frames;

import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

public interface IFrame {

    void open(Player player);

    Inventory getInventory();

    String getName();
}
