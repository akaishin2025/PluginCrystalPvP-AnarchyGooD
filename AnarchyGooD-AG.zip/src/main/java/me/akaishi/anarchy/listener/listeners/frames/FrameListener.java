package me.akaishi.anarchy.listener.listeners.frames;

import me.akaishi.anarchy.event.PlayerPlaceItemInItemFrameEvent;
import me.akaishi.anarchy.util.Utils;
import net.minecraft.server.v1_12_R1.*;
import org.bukkit.Location;
import org.bukkit.Rotation;
import org.bukkit.craftbukkit.v1_12_R1.CraftWorld;
import org.bukkit.craftbukkit.v1_12_R1.entity.CraftItemFrame;
import org.bukkit.entity.ItemFrame;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.hanging.HangingBreakByEntityEvent;
import org.bukkit.event.hanging.HangingPlaceEvent;
import org.bukkit.event.player.PlayerInteractAtEntityEvent;

public class FrameListener implements Listener {

    @EventHandler
    public void onInteract(PlayerInteractAtEntityEvent event) {
        if (!(event.getRightClicked() instanceof ItemFrame)) return;
        Player player = event.getPlayer();
        ItemFrame frame = (ItemFrame) event.getRightClicked();
        if (frame.getItem() == null || frame.getItem().getType().equals(org.bukkit.Material.AIR)) return;
        frame.setRotation(Rotation.COUNTER_CLOCKWISE_45);
        FrameInventory frameInventory = new FrameInventory("%mat%", frame.getItem());
        frameInventory.open(player);
    }

    @EventHandler
    public void onHangingPlaceEvent(HangingPlaceEvent event) {
        if (!event.getPlayer().isOp()) event.setCancelled(true);
    }

    @EventHandler
    public void onHangingBreakByEntity(HangingBreakByEntityEvent event) {
        if (!event.getRemover().isOp()) event.setCancelled(true);
    }

    @EventHandler
    public void onDamage(EntityDamageByEntityEvent event) {
        if (event.getEntity() instanceof ItemFrame) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onItemFramePlace(PlayerPlaceItemInItemFrameEvent event) {
        if (!event.getPlayer().isOp()) {
            event.setCancelled(true);
            Location location = event.getItemFrame().getLocation();
            World world = ((CraftWorld) event.getItemFrame().getWorld()).getHandle();
            EntityItemFrame entityItemFrame = new EntityItemFrame(world, new BlockPosition(location.getX(), location.getY(), location.getZ()), ((CraftItemFrame) event.getItemFrame()).getHandle().direction);
            event.getItemFrame().remove();
            entityItemFrame.setItem(new ItemStack(Item.getById(0)));
            Utils.run(() -> {
                world.addEntity(entityItemFrame);
            });
        }
    }
}
